package com.example.healthmonitor

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.sqrt

class MainActivity : AppCompatActivity(), SensorEventListener {
    private lateinit var sensorManager: SensorManager

    // Declare sensors
    private var accelerometer: Sensor? = null
    private var gyroscope: Sensor? = null
    private var lightSensor: Sensor? = null
    private var barometer: Sensor? = null

    // Declare TextViews for displaying sensor data
    private lateinit var accelerometerReadingText: TextView
    private lateinit var gyroscopeReadingText: TextView
    private lateinit var lightReadingText: TextView
    private lateinit var barometerReadingText: TextView

    // Step counting variables
    private var stepCount = 0
    private var lastMagnitude = 0.0f
    private val stepThreshold = 2.0f  // Lower threshold
    private var lastStepTime = 0L
    private val stepDelayMillis = 150  // Shorter delay
    private var isPeak = false
    private var gravity = FloatArray(3) { 0f }
    private val alpha = 0.8f  // Low-pass filter constant

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize TextViews
        accelerometerReadingText = findViewById(R.id.accelerometer_reading)
        gyroscopeReadingText = findViewById(R.id.gyroscope_reading)
        lightReadingText = findViewById(R.id.light_reading)
        barometerReadingText = findViewById(R.id.barometer_reading)

        // Initialize sensor manager
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager

        // Initialize sensors
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT)
        barometer = sensorManager.getDefaultSensor(Sensor.TYPE_PRESSURE)
    }

    override fun onResume() {
        super.onResume()
        // Register sensor listeners with faster sampling rate
        accelerometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
        gyroscope?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
        lightSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
        barometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    override fun onPause() {
        super.onPause()
        // Unregister sensor listeners to save battery
        sensorManager.unregisterListener(this)
    }

    private fun detectStep(x: Float, y: Float, z: Float) {
        // Apply low-pass filter to isolate gravity
        gravity[0] = alpha * gravity[0] + (1 - alpha) * x
        gravity[1] = alpha * gravity[1] + (1 - alpha) * y
        gravity[2] = alpha * gravity[2] + (1 - alpha) * z

        // Remove gravity contribution to get linear acceleration
        val linearX = x - gravity[0]
        val linearY = y - gravity[1]
        val linearZ = z - gravity[2]

        // Calculate magnitude of linear acceleration
        val magnitude = sqrt(linearX * linearX + linearY * linearY + linearZ * linearZ)
        val currentTime = System.currentTimeMillis()

        // Peak detection algorithm
        if (!isPeak && magnitude > stepThreshold) {
            if (currentTime - lastStepTime > stepDelayMillis) {
                stepCount++
                lastStepTime = currentTime
            }
            isPeak = true
        } else if (magnitude < stepThreshold * 0.8) {  // Reset when magnitude drops below threshold
            isPeak = false
        }

        lastMagnitude = magnitude
    }

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> {
                val x = event.values[0]
                val y = event.values[1]
                val z = event.values[2]
                detectStep(x, y, z)

                accelerometerReadingText.text = """
                    Physical Activity Tracking:
                    • Steps Taken: $stepCount steps
                    • Movement Data:
                      - Forward/Backward (X): %.2f m/s²
                      - Side to Side (Y): %.2f m/s²
                      - Up/Down (Z): %.2f m/s²
                    • Activity Intensity: ${getActivityIntensity(x, y, z)}
                """.trimIndent().format(x, y, z)
            }
            Sensor.TYPE_GYROSCOPE -> {
                val x = event.values[0]
                val y = event.values[1]
                val z = event.values[2]
                gyroscopeReadingText.text = """
                    Posture Assessment:
                    • Rotation Rate:
                      - Forward Tilt: %.2f rad/s
                      - Side Tilt: %.2f rad/s
                      - Twist: %.2f rad/s
                    • Posture Status: ${getPostureStatus(y)}
                """.trimIndent().format(x, y, z)
            }
            Sensor.TYPE_LIGHT -> {
                val light = event.values[0]
                lightReadingText.text = """
                    Environmental Light Analysis:
                    • Current Light Level: %.1f lux
                    • Environment Type: ${getLightEnvironment(light)}
                    • Sleep Quality Impact: ${getSleepImpact(light)}
                """.trimIndent().format(light)
            }
            Sensor.TYPE_PRESSURE -> {
                val pressure = event.values[0]
                val altitude = SensorManager.getAltitude(
                    SensorManager.PRESSURE_STANDARD_ATMOSPHERE,
                    pressure
                )
                barometerReadingText.text = """
                    Altitude & Pressure Metrics:
                    • Atmospheric Pressure: %.1f hPa
                    • Estimated Altitude: %.1f meters
                    • Activity Level: ${getAltitudeImpact(altitude)}
                """.trimIndent().format(pressure, altitude)
            }
        }
    }

    private fun getActivityIntensity(x: Float, y: Float, z: Float): String {
        val magnitude = sqrt(x * x + y * y + z * z)
        return when {
            magnitude < 2.0f -> "Low (Resting/Standing)"
            magnitude < 5.0f -> "Moderate (Walking)"
            else -> "High (Running/Active)"
        }
    }

    private fun getPostureStatus(tilt: Float): String {
        return when {
            tilt > 0.5 -> "Leaning Forward - Please Correct"
            tilt < -0.5 -> "Leaning Backward - Please Correct"
            else -> "Good Posture"
        }
    }

    private fun getLightEnvironment(light: Float): String {
        return when {
            light < 10 -> "Dark Environment"
            light < 100 -> "Indoor Lighting"
            light < 1000 -> "Bright Indoor"
            else -> "Outdoor/Sunlight"
        }
    }

    private fun getSleepImpact(light: Float): String {
        return when {
            light < 5 -> "Optimal for Sleep"
            light < 50 -> "Suitable for Rest"
            else -> "Too Bright for Sleep"
        }
    }

    private fun getAltitudeImpact(altitude: Float): String {
        return when {
            altitude < 500 -> "Low Elevation Activity"
            altitude < 1500 -> "Moderate Elevation Impact"
            else -> "High Altitude Exercise - Take Precautions"
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // Handle accuracy changes if needed
    }
}
